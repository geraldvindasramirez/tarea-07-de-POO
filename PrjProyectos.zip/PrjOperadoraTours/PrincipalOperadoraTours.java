public class PrincipalOperadoraTours {
    public static void main(String[] args) {
        System.out.println("=== Sistema Operadora de Tours - Estudiante: Gerald Vindas Ramírez ===");

        // Creación de guías
        Guia g1 = new Guia("102340567", "María Brenes Mora");
        Guia g2 = new Guia("204560789", "Esteban Solís Castro");

        // Creación de atractivos
        Atractivo a1 = new Atractivo("ATR-01", "Parque Nacional Cahuita", 5000.0);
        Atractivo a2 = new Atractivo("ATR-02", "Refugio Gandoca-Manzanillo", 4000.0);

        // Creación de tours
        Tour t1 = new TourCultural("Historia y Arrecife", 25000.0, 15, g1, "Español");
        Tour t2 = new TourAventura("Cascadas y Canopy", 35000.0, 10, g2, "Alto");

        t1.agregarAtractivo(a1);
        t2.agregarAtractivo(a2);

        // Clientes
        Cliente c1 = new Cliente("Sofía Ramírez", "nacional");
        Cliente c2 = new Cliente("John Smith", "extranjero");

        // Registrar reservas
        t1.registrarReserva(c1, 2);
        t2.registrarReserva(c2, 1);

        // Mostrar resultados
        System.out.println("\n--- DETALLES TOUR 1 ---");
        System.out.println(t1);
        System.out.println("Precio por persona: " + t1.calcularPrecioPorPersona());

        System.out.println("\n--- DETALLES TOUR 2 ---");
        System.out.println(t2);
        System.out.println("Precio por persona: " + t2.calcularPrecioPorPersona());
    }
}