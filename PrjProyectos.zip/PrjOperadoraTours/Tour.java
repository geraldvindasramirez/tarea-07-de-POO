import java.util.ArrayList;

public abstract class Tour {
    public static final String PREFIJO = "TOUR-";
    private static int cantTours = 0;

    protected String codigo;
    protected String nombre;
    protected double precioBase;
    protected int cupoMaximo;
    protected Guia guia;
    protected ArrayList<Atractivo> atractivos;
    protected ArrayList<Reserva> reservas;

    public Tour(String nombre, double precioBase, int cupoMaximo, Guia guia) {
        this.nombre = nombre;
        this.precioBase = precioBase;
        this.cupoMaximo = cupoMaximo;
        this.guia = guia;
        this.atractivos = new ArrayList<>();
        this.reservas = new ArrayList<>();
        cantTours++;
        this.codigo = PREFIJO + cantTours;
    }

    public abstract double calcularPrecioPorPersona();

    public final double calcularIngresoTotal() {
        double total = 0;
        // Suma los montos de todas las reservas registradas
        return total;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String consultarNombreGuia() {
        return guia.getNombreCompleto();
    }

    public void cambiarGuia(Guia nuevoGuia) {
        this.guia = nuevoGuia;
    }

    public void agregarAtractivo(Atractivo a) {
        if (!atractivos.contains(a)) {
            atractivos.add(a);
        }
    }

    public String consultarNombresAtractivos() {
        String res = "";
        for (int i = 0; i < atractivos.size(); i++) {
            res += atractivos.get(i).getNombre();
            if (i < atractivos.size() - 1) {
                res += ", ";
            }
        }
        return res;
    }

    public int calcularCuposDisponibles() {
        int ocupados = 0;
        for (Reserva r : reservas) {
            ocupados += r.getCantidadPersonas();
        }
        return cupoMaximo - ocupados;
    }

    public void registrarReserva(Cliente cliente, int cantidadPersonas) {
        if (cantidadPersonas > 0 && cantidadPersonas <= calcularCuposDisponibles()) {
            int numReserva = reservas.size() + 1;
            Reserva nuevaReserva = new Reserva(numReserva, cliente, cantidadPersonas, calcularPrecioPorPersona());
            reservas.add(nuevaReserva);
        }
    }

    public void registrarReserva(Cliente cliente) {
        registrarReserva(cliente, 1);
    }

    public String toString() {
        String s = "Código: " + codigo + ", Nombre: " + nombre + ", Guía: " + consultarNombreGuia() +
                   ", Cupo Máximo: " + cupoMaximo + ", Cupos Disponibles: " + calcularCuposDisponibles() + 
                   "\nAtractivos: " + consultarNombresAtractivos() + "\n";
        return s;
    }
}