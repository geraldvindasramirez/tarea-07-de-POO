public class TourCultural extends Tour {
    private String idioma;

    public TourCultural(String nombre, double precioBase, int cupoMaximo, Guia guia, String idioma) {
        super(nombre, precioBase, cupoMaximo, guia);
        this.idioma = idioma;
    }

    public double calcularPrecioPorPersona() {
        double sumaAtractivos = 0;
        for (Atractivo a : atractivos) {
            sumaAtractivos += a.getMontoEntrada();
        }
        return precioBase + sumaAtractivos;
    }

    public String toString() {
        return super.toString() + "Idioma: " + idioma + ", Tipo: Cultural\n";
    }
}