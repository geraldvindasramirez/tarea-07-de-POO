public class Reserva {
    private int numero;
    private String nombreCliente;
    private int cantidadPersonas;
    private double monto;

    public Reserva(int numero, Cliente cliente, int cantidadPersonas, double precioPorPersona) {
        this.numero = numero;
        this.nombreCliente = cliente.getNombre();
        this.cantidadPersonas = cantidadPersonas;
        
        double subtotal = precioPorPersona * cantidadPersonas;
        if (cliente.esNacional()) {
            this.monto = subtotal * (1.0 - 0.20); // 20% de descuento para nacionales
        } else {
            this.monto = subtotal;
        }
    }

    public int getCantidadPersonas() {
        return cantidadPersonas;
    }

    public String toString() {
        return "Número de Reserva: " + numero + ", Cliente: " + nombreCliente + 
               ", Personas: " + cantidadPersonas + ", Monto Total: " + monto;
    }
}