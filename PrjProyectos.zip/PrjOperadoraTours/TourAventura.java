public class TourAventura extends Tour {
    public static final double RECARGO_SEGURO = 0.15; // 15% de recargo por equipo y seguro
    private String nivelDificultad;

    public TourAventura(String nombre, double precioBase, int cupoMaximo, Guia guia, String nivelDificultad) {
        super(nombre, precioBase, cupoMaximo, guia);
        this.nivelDificultad = nivelDificultad;
    }

    // Sobrecarga de constructor por defecto
    public TourAventura(String nombre, double precioBase, int cupoMaximo, Guia guia) {
        this(nombre, precioBase, cupoMaximo, guia, "medio");
    }

    public double calcularPrecioPorPersona() {
        return precioBase + (precioBase * RECARGO_SEGURO);
    }

    public String toString() {
        return super.toString() + "Nivel de dificultad: " + nivelDificultad + ", Tipo: Aventura\n";
    }
}