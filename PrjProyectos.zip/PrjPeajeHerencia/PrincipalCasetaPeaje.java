public class PrincipalCasetaPeaje {
    public static void main(String[] args) {
        System.out.println("=== Sistema de Peajes - Estudiante: Gerald Vindas Ramírez ===");
        
        // Creamos una caseta de peaje en la autopista Bernardo Soto
        CasetaPeaje caseta1 = new CasetaPeaje("Autopista Bernardo Soto");

        // Instanciación usando los subtipos específicos (Polimorfismo)
        Vehiculo v1 = new Particular("ABC-123", "Toyota", "Corolla", 2020);
        Vehiculo v2 = new CargaLiviana("CL-7890", "Hyundai", "H100", 2018);
        Vehiculo v3 = new Carga("CAR-999", "Freightliner", "Cascadia", 2022);
        Vehiculo v4 = new Moto("M-555", "Yamaha", "MT-03", 2021);

        // Cobramos el peaje sin usar condicionales (gracias al polimorfismo puro)
        caseta1.cobrarPeaje(v1);
        caseta1.cobrarPeaje(v2);
        caseta1.cobrarPeaje(v3);
        caseta1.cobrarPeaje(v4);

        // Imprimimos el estado de la caseta y los vehículos
        System.out.println(v1);
        System.out.println("Peaje pagado: " + v1.calcularMontoPeaje() + "\n");
        
        System.out.println(v2);
        System.out.println("Peaje pagado: " + v2.calcularMontoPeaje() + "\n");

        System.out.println(v3);
        System.out.println("Peaje pagado: " + v3.calcularMontoPeaje() + "\n");

        System.out.println(v4);
        System.out.println("Peaje pagado: " + v4.calcularMontoPeaje() + "\n");

        System.out.println(caseta1);
    }
}