public class CasetaPeaje {
    private int numeroCaseta;
    private String nombreAutopista;
    private double totalCobrado;
    private static int cantidadCasetas;

    public CasetaPeaje(String nombreAutopista) {
        cantidadCasetas++;
        this.numeroCaseta = cantidadCasetas;
        this.nombreAutopista = nombreAutopista;
        this.totalCobrado = 0.0;
    }

    public void cobrarPeaje(Vehiculo obj) {
        totalCobrado += obj.calcularMontoPeaje();
    }

    public double getTotalCobrado() {
        return totalCobrado;
    }

    public static int getCantidadDeCasetasPeaje() {
        return cantidadCasetas;
    }

    public String toString() {
        return "Caseta de Peaje número: " + numeroCaseta + "\n" + 
               "Autopista= " + nombreAutopista + "\n" + 
               "Total Cobrado= " + totalCobrado + "\n"; 
    }
}