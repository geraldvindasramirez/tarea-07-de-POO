public abstract class Vehiculo {
    protected String placa;
    protected String marca;
    protected String modelo;
    protected int annio;

    public Vehiculo(String placa, String marca, String modelo, int annio) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.annio = annio;
    }

    public abstract double calcularMontoPeaje();

    public abstract String getTipo();

    public String toString() {
        return "Placa= " + placa + "\n" + 
               "Tipo= " + getTipo() + "\n" + 
               "Marca= " + marca + "\n" + 
               "Modelo= " + modelo + "\n" + 
               "Año= " + annio;
    }
}

