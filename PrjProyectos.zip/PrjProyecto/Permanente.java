public class Permanente extends Proyecto {
    private double mantenimientoAnual;

    public Permanente(String nombre, double costoInicial, double mantenimientoAnual) {
        super(nombre, costoInicial);
        this.mantenimientoAnual = mantenimientoAnual;
    }

    public double calcularCostoActual() {
        return costoInicial + mantenimientoAnual;
    }

    public String toString() {
        return super.toString() + "Mantenimiento anual: " + mantenimientoAnual + "\nTipo: Permanente\n";
    }
}