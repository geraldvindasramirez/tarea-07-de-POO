public class Temporal extends Proyecto {
    private int mesesPlazo;

    public Temporal(String nombre, double costoInicial, int mesesPlazo) {
        super(nombre, costoInicial);
        this.mesesPlazo = mesesPlazo;
    }

    public double calcularCostoActual() {
        return costoInicial + (mesesPlazo * 50000.0); // Ejemplo de cálculo temporal
    }

    public String toString() {
        return super.toString() + "Plazo en meses: " + mesesPlazo + "\nTipo: Temporal\n";
    }
}