public class Entregable {
    private String descripcion;
    private String fechaEntrega;
    private boolean estado;

    public Entregable(String descripcion, String fechaEntrega, boolean estado) {
        this.descripcion = descripcion;
        this.fechaEntrega = fechaEntrega;
        this.estado = estado;
    }

    public String toString() {
        String estadoStr = estado ? "Entregado" : "Pendiente";
        return "Descripción: " + descripcion + ", Fecha: " + fechaEntrega + ", Estado: " + estadoStr;
    }
}