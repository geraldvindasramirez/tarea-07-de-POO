public class Persona {
    private String cedula;
    private String nombre;
    private String telefono;
    private Proyecto miProyecto; // Asociación bidireccional

    public Persona(String cedula, String nombre, String telefono) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.telefono = telefono;
        this.miProyecto = null;
    }

    public void asignarProyecto(Proyecto p) {
        this.miProyecto = p;
    }

    public double devolverCostoActualPrj() {
        if (miProyecto != null) {
            return miProyecto.calcularCostoActual();
        }
        return 0.0;
    }

    public String toString() {
        return "Cédula: " + cedula + ", Nombre: " + nombre + ", Teléfono: " + telefono;
    }
}   