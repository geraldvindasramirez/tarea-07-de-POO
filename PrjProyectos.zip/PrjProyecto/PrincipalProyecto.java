public class PrincipalProyecto {
    public static void main(String[] args) {
        System.out.println("=== Sistema de Gestión de Proyectos - Estudiante: Gerald Vindas Ramírez ===");

        Persona p1 = new Persona("11223344", "Carlos Gómez", "8888-1111");
        Persona p2 = new Persona("55667788", "Ana María Rojas", "8888-2222");

        Proyecto proy1 = new Temporal("Rediseño Web", 500000.0, 6);
        Proyecto proy2 = new Permanente("Infraestructura Redes", 2000000.0, 150000.0);

        proy1.asignarEncargado(p1);
        proy2.asignarEncargado(p2);

        proy1.registrarIngreso(800000.0);
        proy2.registrarIngreso(3500000.0);

        proy1.registrarEntregable(new Entregable("Prototipo UI", "2026-10-15", true));
        proy2.registrarEntregable(new Entregable("Cableado estructurado", "2026-11-01", false));

        System.out.println("\n--- DETALLES PROYECTO 1 ---");
        System.out.println(proy1);

        System.out.println("\n--- DETALLES PROYECTO 2 ---");
        System.out.println(proy2);
    }
}